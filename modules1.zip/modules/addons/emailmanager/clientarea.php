<?php
function emailmanager_clientarea() {
    $client_id = $_SESSION['uid'];
    
    if ($_POST['save_preferences']) {
        // Save preferences
        $disable_invoice = (int)$_POST['disable_invoice'];
        $disable_domain = (int)$_POST['disable_domain'];
        $disable_hosting = (int)$_POST['disable_hosting'];
        $disable_product = (int)$_POST['disable_product'];
        $disable_all = (int)$_POST['disable_all'];
        
        // Update or insert preferences
        $query = "INSERT INTO mod_email_preferences 
                 (client_id, disable_invoice, disable_domain, disable_hosting, disable_product, disable_all)
                 VALUES ($client_id, $disable_invoice, $disable_domain, $disable_hosting, $disable_product, $disable_all)
                 ON DUPLICATE KEY UPDATE
                 disable_invoice=$disable_invoice,
                 disable_domain=$disable_domain,
                 disable_hosting=$disable_hosting,
                 disable_product=$disable_product,
                 disable_all=$disable_all";
        
        full_query($query);
    }
    
    return array(
        'pagetitle' => 'Email Notification Settings',
        'breadcrumb' => array('index.php?m=emailmanager' => 'Email Preferences'),
        'templatefile' => 'templates/clientarea',
        'vars' => array(
            'preferences' => get_client_preferences($client_id)
        ),
    );
}
