<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}
  function emailmanager_clientarea($vars) {
      $smarty = $vars['smarty'];
      $client_id = $_SESSION['uid'];
    
      if ($_GET['action'] == 'save') {
          $userid = $_SESSION['uid'];
          $prefs = $_POST['prefs'];
        
          $values = [
              'client_id' => $userid,
              'disable_invoice' => isset($prefs['disable_invoice']) ? 1 : 0,
              'disable_domain' => isset($prefs['disable_domain']) ? 1 : 0,
              'disable_hosting' => isset($prefs['disable_hosting']) ? 1 : 0,
              'disable_product' => isset($prefs['disable_product']) ? 1 : 0,
              'disable_all' => isset($prefs['disable_all']) ? 1 : 0,
          ];
        
          insert_query('mod_email_preferences', $values, true);
        
          redir('action=preferences&success=true');
      }
    
      // Get current preferences
      $result = select_query('mod_email_preferences', '*', array('client_id' => $client_id));
      $data = mysql_fetch_array($result);
    
      return array(
          'pagetitle' => 'Email Preferences',
          'breadcrumb' => array('index.php?m=emailmanager' => 'Email Settings'),
          'templatefile' => 'templates/clientarea',
          'requirelogin' => true,
          'vars' => array(
              'preferences' => $data,
          ),
      );
  }
