<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

add_hook('ClientAreaPageClientSummary', 1, function($vars) {
    $userid = $vars['userid'];
    return array(
        'emailPreferences' => getClientEmailPreferences($userid)
    );
});

add_hook('AdminClientSummaryPage', 1, function($vars) {
    $userid = $_GET['userid'];
    
    return <<<HTML
    <div class="clientsummaryactions">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Email Preferences</h3>
            </div>
            <div class="panel-body">
                <form method="post" action="clientssummary.php?userid={$userid}&action=saveemailprefs">
                    <div class="form-group">
                        <label class="checkbox">
                            <input type="checkbox" name="disable_invoice" value="1"> 
                            Disable Invoice Emails
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="checkbox">
                            <input type="checkbox" name="disable_domain" value="1"> 
                            Disable Domain Emails
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="checkbox">
                            <input type="checkbox" name="disable_hosting" value="1"> 
                            Disable Hosting Emails
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="checkbox">
                            <input type="checkbox" name="disable_product" value="1"> 
                            Disable Product Emails
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="checkbox">
                            <input type="checkbox" name="disable_all" value="1"> 
                            Disable All Emails
                        </label>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Preferences</button>
                </form>
            </div>
        </div>
    </div>
HTML;
});

add_hook('EmailPreSend', 1, function($vars) {
    $client_id = $vars['userid'];
    
    // Get client preferences
    $result = select_query('mod_email_preferences', '*', array('client_id' => $client_id));
    $data = mysql_fetch_array($result);
    
    if ($data['disable_all']) {
        return false;
    }
    
    // Check email type and disable based on preferences
    $email_template = $vars['messagename'];
    
    if ($data['disable_invoice'] && strpos($email_template, 'invoice') !== false) {
        return false;
    }
    
    if ($data['disable_domain'] && strpos($email_template, 'domain') !== false) {
        return false;
    }
    
    if ($data['disable_hosting'] && strpos($email_template, 'hosting') !== false) {
        return false;
    }
    
    if ($data['disable_product'] && strpos($email_template, 'product') !== false) {
        return false;
    }
    
    return true;
});
