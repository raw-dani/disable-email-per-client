<?php
$_ADDONLANG['preference_saved'] = "Email preferences saved successfully";
$_ADDONLANG['disable_all'] = "Disable All Notifications";
$_ADDONLANG['disable_invoice'] = "Disable Invoice Notifications";
