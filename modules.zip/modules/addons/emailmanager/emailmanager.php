<?php
function emailmanager_config() {
    return [
        'name' => 'Client Email Manager',
        'description' => 'Manage email notifications per client',
        'version' => '1.0',
        'author' => 'Rohmat Ali Wardani',
    ];
}

function emailmanager_activate() {
    // Create custom table for storing client email preferences
    $query = "CREATE TABLE IF NOT EXISTS `mod_email_preferences` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `client_id` int(11) NOT NULL,
        `disable_invoice` tinyint(1) DEFAULT 0,
        `disable_domain` tinyint(1) DEFAULT 0,
        `disable_hosting` tinyint(1) DEFAULT 0,
        `disable_product` tinyint(1) DEFAULT 0,
        `disable_all` tinyint(1) DEFAULT 0,
        PRIMARY KEY (`id`)
    )";
    
    return full_query($query);
}
