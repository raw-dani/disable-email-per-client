<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function emailmanager_clientarea($vars) {
    $smarty = $vars['smarty'];
    $client_id = $_SESSION['uid'];
    
    // Handle form submission
    if ($_POST['save_preferences']) {
        $values = array(
            'client_id' => $client_id,
            'disable_invoice' => isset($_POST['disable_invoice']) ? 1 : 0,
            'disable_domain' => isset($_POST['disable_domain']) ? 1 : 0,
            'disable_hosting' => isset($_POST['disable_hosting']) ? 1 : 0,
            'disable_product' => isset($_POST['disable_product']) ? 1 : 0,
            'disable_all' => isset($_POST['disable_all']) ? 1 : 0,
        );
        
        insert_query('mod_email_preferences', $values, true);
    }
    
    // Get current preferences
    $result = select_query('mod_email_preferences', '*', array('client_id' => $client_id));
    $data = mysql_fetch_array($result);
    
    return array(
        'pagetitle' => 'Email Preferences',
        'breadcrumb' => array('index.php?m=emailmanager' => 'Email Settings'),
        'templatefile' => 'templates/clientarea',
        'requirelogin' => true,
        'vars' => array(
            'preferences' => $data,
        ),
    );
}
