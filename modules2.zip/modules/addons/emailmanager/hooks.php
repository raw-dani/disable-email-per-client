<?php
add_hook('EmailPreSend', 1, function($vars) {
    $client_id = $vars['userid'];
    
    // Get client preferences
    $result = select_query('mod_email_preferences', '*', array('client_id' => $client_id));
    $data = mysql_fetch_array($result);
    
    if ($data['disable_all']) {
        return false;
    }
    
    // Check email type and disable based on preferences
    $email_template = $vars['messagename'];
    
    if ($data['disable_invoice'] && strpos($email_template, 'invoice') !== false) {
        return false;
    }
    
    if ($data['disable_domain'] && strpos($email_template, 'domain') !== false) {
        return false;
    }
    
    if ($data['disable_hosting'] && strpos($email_template, 'hosting') !== false) {
        return false;
    }
    
    if ($data['disable_product'] && strpos($email_template, 'product') !== false) {
        return false;
    }
    
    return true;
});
